﻿using Database.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAppWithAPI.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _EmployeeRepository;
        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _EmployeeRepository = employeeRepository;
        }

        [HttpGet]
        public ActionResult GetEmployees()
        {
        
            
                try
                {
                    var employees = _EmployeeRepository.GetEmployees();
                    return Ok(employees);
                }
                catch (Exception ex)
                {
                    return StatusCode(
                        StatusCodes.Status417ExpectationFailed,ex.Message);
                }
            
        }

        [HttpGet]
        public ActionResult GetEmployeeById(int Id)
        {
            try
            {
                var employee = _EmployeeRepository.GetEmployeeById(Id);
                return Ok(employee);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status417ExpectationFailed, ex.Message);
            }
        }


        [HttpPost]
        public ActionResult AddEmployees(Employees employees) 
        {
            try 
            {
                var addemployees = _EmployeeRepository.AddEmployees(employees);
                return Ok(addemployees);
            }
            catch (Exception ex) 
            {
                return StatusCode(StatusCodes.Status417ExpectationFailed, ex.Message);
            }
            
        }
    }
}
