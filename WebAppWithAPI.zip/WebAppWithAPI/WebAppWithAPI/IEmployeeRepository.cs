﻿using Database.Models;

internal interface IEmployeeRepository
{
    object AddEmployees(Employees employees);
    object GetEmployeeById(int id);
    object GetEmployees();
}