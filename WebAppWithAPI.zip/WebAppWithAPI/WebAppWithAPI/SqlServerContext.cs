﻿internal class SqlServerContext
{
}