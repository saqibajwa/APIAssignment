﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database.Models
{
    public class Employees
    {
        public int emloyee_id { get; set; }
        public string? First_Name { get; set; }
    }
}
