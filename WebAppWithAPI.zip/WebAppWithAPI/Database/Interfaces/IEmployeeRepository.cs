﻿using Database.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace Database.Interfaces
{
    public interface IEmployeeRepository
    {
        List<Employees> GetEmployees();

        Employees GetEmployees(int id);

        Employees AddEmployees(Employees employee);
    }
}
