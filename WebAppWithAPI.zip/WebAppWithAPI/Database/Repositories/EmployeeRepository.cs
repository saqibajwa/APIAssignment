﻿using Database.DatabaseContext;
using Database.Interfaces;
using Database.Models;
using Microsoft.EntityFrameworkCore;
namespace Database.Repositories
{
    internal class EmployeeRepository : IEmployeeRepository
    {
        private readonly SqlServerContext _SqlServerContext;

        public EmployeeRepository(SqlServerContext sqlServerContext)
        {
            _SqlServerContext = sqlServerContext;
        }

       public List<Employees> GetEmployees()
        {
            var lstEmployees = _SqlServerContext.Employees.ToList();
            return lstEmployees;
        }

        public Employees GetEmployees(int id)
        {
            var Employees = _SqlServerContext.Employees.FirstOrDefault(x => x.emloyee_id == id);
            return Employees;
        }

        public Employees AddEmployees(Employees employee)
        {
            _SqlServerContext.Employees.Add(employee);
            _SqlServerContext.SaveChanges();
            return employee;
        }

        List<Employees> IEmployeeRepository.GetEmployees()
        {
            throw new NotImplementedException();
        }

        Employees IEmployeeRepository.GetEmployees(int id)
        {
            throw new NotImplementedException();
        }

        public Employees AddEmployee(Employees employee)
        {
            throw new NotImplementedException();
        }
    }
}
